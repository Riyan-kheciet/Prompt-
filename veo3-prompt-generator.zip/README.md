# Veo 3 Prompt Generator 🎬

A simple web-based tool to generate high-quality video prompts for Veo 3 AI model. Supports presets (Action, Romance, Edukasi), auto-formatted output, clipboard copy, and .txt export.

🚀 Built with vanilla HTML/JS  
🎯 Designed for creators, marketers, and AI prompt engineers

## 🔗 Live Preview
Use this tool via GitHub Pages after uploading.

## ✍️ Usage
1. Fill out scene details and options.
2. Generate your prompt.
3. Copy or export as needed.

Made with ❤️ by [YourName]
